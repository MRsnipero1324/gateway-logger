from fastapi import APIRouter, Request, Response
import httpx
from .database import SessionLocal
from .models import Log
import os

router = APIRouter()

SERVICES = {
    "personas": os.getenv("MS_PERSONAS", "http://ms-personas:8001"),
    "consulta": os.getenv("MS_CONSULTA", "http://ms-consulta:8002"),
    "rag": os.getenv("MS_RAG", "http://ms-rag:8003")
}

@router.api_route("/{service}/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def proxy(service: str, path: str, request: Request):

    if service not in SERVICES:
        return {"error": "Microservicio no encontrado"}

    body = await request.body()
    headers = dict(request.headers)
    accion = f"{request.method} {service}/{path}"

    db = SessionLocal()
    new_log = Log(accion=accion, resultado="Pendiente")
    db.add(new_log)
    db.commit()
    db.refresh(new_log)

    target_url = f"{SERVICES[service]}/{path}"

    try:
        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=request.method,
                url=target_url,
                content=body,
                headers=headers,
                timeout=15.0
            )

        new_log.resultado = "Completado"
        db.commit()

        return Response(
            content=response.content,
            status_code=response.status_code,
            headers=response.headers
        )

    except Exception as e:
        new_log.resultado = "Fallido"
        db.commit()
        return {"error": "Fallo en el microservicio", "detalle": str(e)}
